.. code:: ipython3

    import pandas as pd
    import seaborn as sns
    import matplotlib.pyplot as plt
    
    data = {
        'Customer_ID': list(range(101, 131)),
    
        'Age': [
            22, 25, 30, 35, 40, 28, 45, 50, 32, 38,
            26, 42, 55, 29, 33, 48, 36, 24, 52, 41,
            31, 27, 46, 39, 34, 57, 44, 23, 37, 49
        ],
    
        'Gender': [
            'Male', 'Female', 'Male', 'Female', 'Male',
            'Female', 'Male', 'Female', 'Male', 'Female',
            'Female', 'Male', 'Female', 'Male', 'Female',
            'Male', 'Female', 'Male', 'Female', 'Male',
            'Female', 'Male', 'Female', 'Male', 'Female',
            'Male', 'Female', 'Male', 'Female', 'Male'
        ],
    
        'Account_Type': [
            'Savings', 'Current', 'Savings', 'Salary', 'Current',
            'Savings', 'Salary', 'Current', 'Savings', 'Salary',
            'Current', 'Savings', 'Salary', 'Savings', 'Current',
            'Salary', 'Savings', 'Current', 'Salary', 'Savings',
            'Current', 'Salary', 'Savings', 'Current', 'Salary',
            'Savings', 'Current', 'Salary', 'Savings', 'Current'
        ],
    
        'Balance': [
            15000, 25000, 12000, 45000, 30000,
            18000, 65000, 55000, 22000, 40000,
            14000, 35000, 80000, 16000, 28000,
            70000, 24000, 19000, 90000, 42000,
            21000, 50000, 32000, 38000, 26000,
            95000, 47000, 17000, 29000, 60000
        ],
    
        'Monthly_Income': [
            20000, 30000, 25000, 50000, 40000,
            22000, 65000, 60000, 35000, 45000,
            18000, 42000, 75000, 23000, 32000,
            70000, 38000, 21000, 85000, 48000,
            27000, 55000, 62000, 43000, 36000,
            90000, 52000, 19000, 41000, 68000
        ],
    
        'Loan_Amount': [
            50000, 100000, 40000, 200000, 150000,
            60000, 250000, 180000, 80000, 120000,
            45000, 130000, 300000, 55000, 90000,
            280000, 75000, 50000, 350000, 160000,
            70000, 220000, 140000, 110000, 85000,
            400000, 190000, 60000, 95000, 240000
        ],
    
        'Credit_Score': [
            650, 720, 610, 780, 740,
            680, 800, 760, 690, 750,
            620, 730, 820, 640, 700,
            790, 710, 630, 830, 770,
            670, 780, 740, 720, 690,
            850, 760, 660, 710, 800
        ],
    
        'City': [
            'Delhi', 'Mumbai', 'Delhi', 'Pune', 'Mumbai',
            'Delhi', 'Bengaluru', 'Pune', 'Mumbai', 'Delhi',
            'Pune', 'Bengaluru', 'Mumbai', 'Delhi', 'Pune',
            'Mumbai', 'Bengaluru', 'Delhi', 'Mumbai', 'Pune',
            'Delhi', 'Bengaluru', 'Mumbai', 'Pune', 'Delhi',
            'Mumbai', 'Bengaluru', 'Delhi', 'Pune', 'Mumbai'
        ],
    
        'Loan_Status': [
            'Approved', 'Approved', 'Rejected', 'Approved', 'Approved',
            'Rejected', 'Approved', 'Approved', 'Rejected', 'Approved',
            'Rejected', 'Approved', 'Approved', 'Rejected', 'Approved',
            'Approved', 'Approved', 'Rejected', 'Approved', 'Approved',
            'Rejected', 'Approved', 'Approved', 'Approved', 'Rejected',
            'Approved', 'Approved', 'Rejected', 'Approved', 'Approved'
        ]
    }
    
    df = pd.DataFrame(data)
    
    #print(df.head())
    #print(df.shape)
    #print(df.info())

.. code:: ipython3

    # Seaborn Library – 18 Important Practice Questions
    
    # 1. Create a scatter plot to show the relationship between bank balance and credit score. Use different colours to represent account types.
    df = pd.DataFrame(data)
    sns.scatterplot(data=df,x="Balance",y="Credit_Score", hue="Account_Type")
    plt.xlabel("Bank Balance")
    plt.ylabel("Credit Score")
    plt.title("Bank Balance vs Credit Score")
    plt.show()
    



.. image:: output_1_0.png


.. code:: ipython3

    # 2. Create a box plot to compare loan amounts across different cities.
    sns.boxplot(data=df,x="City",y="Loan_Amount")
    plt.xlabel("Cities")
    plt.ylabel("Loan_Amount")
    plt.title("Cities vs Loan_Amount")
    plt.show()
    



.. image:: output_2_0.png


.. code:: ipython3

    # 3. Create a scatter plot to show the relationship between age and monthly income. Use different colours to represent customer gender.
    
    sns.scatterplot(data=df,x="Age",y="Monthly_Income", hue="Gender")
    plt.xlabel("Age")
    plt.ylabel("Monthly_Income")
    plt.title("Age vs Monthly_Income")
    plt.show()



.. image:: output_3_0.png


.. code:: ipython3

    # 4. Create a bar plot to compare the average monthly income across different account types.
    
    sns.barplot(data=df,x="Monthly_Income",y="Account_Type")
    plt.xlabel("Monthly_Income")
    plt.ylabel("Account_Type")
    plt.title("Monthly_Income vs Account_Type")
    plt.show()



.. image:: output_4_0.png


.. code:: ipython3

    # 5. Create a count plot to display loan status for each account type. Use different colours for loan status.
    sns.countplot(data=df,x="Account_Type",hue="Loan_Status")
    plt.xlabel("Account_Type")
    plt.ylabel("Number of Customers")
    plt.title("Loan Status by Account Type")
    plt.show()
    



.. image:: output_5_0.png


.. code:: ipython3

    # 6. Create a bar plot to compare the average loan amount across different cities.
    sns.barplot(data=df,x="City",y="Loan_Amount")
    plt.xlabel("Cities")
    plt.ylabel("Loan_Amount")
    plt.title("loan amount across different cities")
    plt.show()
    



.. image:: output_6_0.png


.. code:: ipython3

    # 7. Create a box plot to identify potential outliers in monthly income.
    sns.boxplot(data=df,x="Monthly_Income")
    plt.xlabel("Monthly_Income")
    plt.title("Box Plot of Monthly Income")
    
    plt.show()



.. image:: output_7_0.png


.. code:: ipython3

    # 8. Create a scatter plot to compare credit score and loan amount. Use different colours for approved and rejected loans.
    
    sns.scatterplot(data=df,x="Credit_Score",y="Loan_Amount",hue="Loan_Status")
    plt.xlabel("Credit_Score")
    plt.ylabel("Loan_Amount")
    plt.title("Credit_Score vs loan amount")
    plt.show()



.. image:: output_8_0.png


.. code:: ipython3

    # 9. Create a bar plot to compare the average credit scores of male and female customers.
    
    sns.barplot(data=df,x="Gender",y="Credit_Score")
    plt.xlabel("Gender")
    plt.ylabel("Credit_Score")
    plt.title("Gender vs Credit_Score")
    plt.show()



.. image:: output_9_0.png


.. code:: ipython3

    # 10. Create a heatmap to display correlations between all numerical columns. Show correlation values inside the heatmap.
    
    correlation = df.set_index("Customer_ID").corr(numeric_only=True)
    
    sns.heatmap(data=correlation,annot=True,cmap="coolwarm")
    plt.title("Correlation Heatmap of Numerical Columns")
    
    plt.show()
    
    
    



.. image:: output_10_0.png


